sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("qualityportalQualityPortal.controller.QPDashboard", {
		onInit: function() {
			var sModel = sap.ui.getCore().getModel("baseinfo");
			var myData = sModel.getData();
			window.console.log(myData);
			this.getView().byId("userdetails").setText("Hello" + ", " + myData.Username + "(" + myData.Designation + ")");
		},
		onIL: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("QPInspLot");
		},
		onRR: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("QPResultRec");
		},
		onUD: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("QPUsageDeci");
		},
		onLogout: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("QPLoginPage");
		}

	});

});