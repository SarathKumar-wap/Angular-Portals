sap.ui.define([
	"sap/ui/core/mvc/Controller", "sap/ui/model/Filter"  ,  "sap/ui/model/FilterOperator" , "sap/ui/model/json/JSONModel"
], function(Controller, Filter, FilterOperator, JSONModel) {
	"use strict";

	return Controller.extend("MaintenancePortalMaintenancePortal.controller.workorder", {
		onInit: function() {
			// var sModel = sap.ui.getCore().getModel("baseinfo");
			// var myData = sModel.getData();
			var service = "/sap/opu/odata/sap/ZODATA_SK_MP_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(service, true);
			var uri = "ZSK_WO_LISTSet";
			var no;
			oModel.read(uri, {
				context: null,
				urlParameters: null,
				async: false,
				success: function(oData, oResponse) {
					no = oData.results;

					window.console.log(no);
				}
			});
			var ooModel = new JSONModel(no);
			this.getView().setModel(ooModel, "wo_list");
		},
		onSearch: function(oEvt) {
			var aFilters = [];
			var sQuery = oEvt.getSource().getValue();
			window.console.log(sQuery);
			if (sQuery && sQuery.length > 0) {
				var filter = new Filter("Orderid", FilterOperator.Contains, sQuery);
				aFilters.push(filter);
			}
			// update list binding
			var list = this.getView().byId("workordertable");
			var binding = list.getBinding("items");
			binding.filter(aFilters, "Application");
		},
		_getDialog1: function() {
			if (!this._oDialog1) {
				this._oDialog1 = sap.ui.xmlfragment("MaintenancePortalMaintenancePortal.view.Fragments.wodialog", this);
				this.getView().addDependent(this._oDialog1);
			}
			return this._oDialog1;
		},
		wodetails_no: function(oEvent) {
			this._getDialog1().open();
			var objcurrent1 = oEvent.getSource().getSelectedContexts()[0].getObject();
			var mat1 = new sap.ui.model.json.JSONModel(objcurrent1);
			this._oDialog1.setModel(mat1);
		},
		onClose1: function() {
			this._getDialog1().close();
		},
		ongoto: function() {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("dashboard");
			}
			/**
			 * Called when a controller is instantiated and its View controls (if available) are already created.
			 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
			 * @memberOf MaintenancePortalMaintenancePortal.view.workorder
			 */
			//	onInit: function() {
			//
			//	},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf MaintenancePortalMaintenancePortal.view.workorder
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf MaintenancePortalMaintenancePortal.view.workorder
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf MaintenancePortalMaintenancePortal.view.workorder
		 */
		//	onExit: function() {
		//
		//	}

	});

});