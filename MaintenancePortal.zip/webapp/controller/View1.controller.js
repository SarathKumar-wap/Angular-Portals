sap.ui.define([
	"sap/ui/core/mvc/Controller", "sap/m/MessageToast"
], function(Controller, MessageToast) {
	"use strict";

	return Controller.extend("MaintenancePortalMaintenancePortal.controller.View1", {

		onPress: function() {
			var user = this.getView().byId("name").getValue();
			var pass = this.getView().byId("password").getValue();
			window.console.log(user, pass);

			if (user !== "" && pass !== "") {

				var surl = '/sap/opu/odata/sap/ZODATA_SK_MP_SRV/';
				var oModel = new sap.ui.model.odata.ODataModel(surl, true);
				var uri = "Userid='" + user + "',Password='" + pass + "'";
				window.console.log(uri);
				var userdata;
				var status;
				oModel.read("/ZSK_LOGIN_ETSet(" + uri + ")", {
					context: null,
					urlParameters: null,
					async: false,
					success: function(oData, OResponse) {
						window.console.log("Success", oData);
						// window.console.log("Response", OResponse);
						// name = oData["Userid"];
						// passwrd = oData["Password"];
						userdata = oData;
						status = oData["Message"];
					}
				});

				// var users = {
				// 	"user": name,
				// 	"password": passwrd
				// };

				var sampleModel = new sap.ui.model.json.JSONModel(userdata);
				sap.ui.getCore().setModel(sampleModel, "baseinfo");

				if (status === "Success") {
					MessageToast.show("Login Successful");
					var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					oRouter.navTo("dashboard");

				} else if (status === "Incorrect Password") {
					MessageToast.show("Incorrect Password!");
					window.console.log("incorrect password");
				} else {
					// this.getRouter().navTo();
					var error2 = 'Incorrect User';
					MessageToast.show(error2);
					window.console.log("incorrect user");
				}

			} else {
				MessageToast.show("Fill out the Required Fields");

			}
			user.setValue(" ");
			pass.setValue(" ");

		}
	});
});