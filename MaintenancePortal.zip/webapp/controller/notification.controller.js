sap.ui.define([
	"sap/ui/core/mvc/Controller", "sap/ui/model/Filter", "sap/ui/model/FilterOperator","sap/ui/model/json/JSONModel" 
], function(Controller, Filter, FilterOperator, JSONModel) {
	"use strict";

	return Controller.extend("MaintenancePortalMaintenancePortal.controller.notification", {
		onInit: function() {
			// var sModel = sap.ui.getCore().getModel("baseinfo");
			// var myData = sModel.getData();
			var service = "/sap/opu/odata/sap/ZODATA_SK_MP_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(service, true);
			var uri = "ZSK_NOTI_LISTSet?$filter=Plangroup eq '010' and Planplant eq '0001' &$format=json";
			var no;
			oModel.read(uri, {
				context: null,
				urlParameters: null,
				async: false,
				success: function(oData, oResponse) {
					no = oData.results;
				}
			});
			var ooModel = new JSONModel(no);
			this.getView().setModel(ooModel, "noti_list");
		},
		onSearch: function(oEvt) {
			var aFilters = [];
			var sQuery = oEvt.getSource().getValue();
			window.console.log(sQuery);
			if (sQuery && sQuery.length > 0) {
				var filter = new Filter("Notificat", FilterOperator.Contains, sQuery);
				aFilters.push(filter);
			}
			// update list binding
			var list = this.getView().byId("notificationtable");
			var binding = list.getBinding("items");
			binding.filter(aFilters, "Application");
		},

		_getDialog: function() {
			if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment("MaintenancePortalMaintenancePortal.view.Fragments.dialog", this);
				this.getView().addDependent(this._oDialog);
			}
			return this._oDialog;
		},
		displaydetails_no: function(oEvent) {
			this._getDialog().open();
			var objcurrent = oEvent.getSource().getSelectedContexts()[0].getObject();
			var mat = new sap.ui.model.json.JSONModel(objcurrent);
			this._oDialog.setModel(mat);
		},
		onClose: function() {
			this._getDialog().close();
		},
		ongoto: function() {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("dashboard");
			}
			/**
			 * Called when a controller is instantiated and its View controls (if available) are already created.
			 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
			 * @memberOf MaintenancePortalMaintenancePortal.view.notification
			 */
			//	onInit: function() {
			//
			//	},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf MaintenancePortalMaintenancePortal.view.notification
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf MaintenancePortalMaintenancePortal.view.notification
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf MaintenancePortalMaintenancePortal.view.notification
		 */
		//	onExit: function() {
		//
		//	}

	});

});