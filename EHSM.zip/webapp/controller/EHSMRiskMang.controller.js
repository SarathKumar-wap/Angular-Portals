sap.ui.define([
	"sap/ui/core/mvc/Controller", "sap/ui/model/Filter", "sap/ui/model/FilterOperator", "sap/ui/model/json/JSONModel"
], function(Controller, Filter, FilterOperator, JSONModel) {
	"use strict";

	return Controller.extend("EHSMEHSM.controller.EHSMRiskMang", {
		onInit: function() {
			// var sModel = sap.ui.getCore().getModel("baseinfo");
			// var myData = sModel.getData();
			var service = "/sap/opu/odata/sap/ZODATA_EHSM_SK_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(service, true);
			var uri = "Z_EHSM_RISK_ETSet";
			var no;
			oModel.read(uri, {
				context: null,
				urlParameters: null,
				async: false,
				success: function(oData, oResponse) {
					no = oData.results;
					window.console.log(oData.results);
				}
			});
			var ooModel = new JSONModel(no);
			this.getView().setModel(ooModel, "risk_list");
		},
		onSearch: function(oEvt) {
			var aFilters = [];
			var sQuery = oEvt.getSource().getValue();
			window.console.log(sQuery);
			if (sQuery && sQuery.length > 0) {
				var filter = new Filter("Recn", FilterOperator.Contains, sQuery);
				aFilters.push(filter);
			}
			// update list binding
			var list = this.getView().byId("risktable");
			var binding = list.getBinding("items");
			binding.filter(aFilters, "Application");
		},

		_getDialog2: function() {
			if (!this._oDialog2) {
				this._oDialog2 = sap.ui.xmlfragment("EHSMEHSM.view.Fragments.risk", this);
				this.getView().addDependent(this._oDialog2);
			}
			return this._oDialog2;
		},
		displaydetails_risk: function(oEvent) {
			this._getDialog2  ().open();
			var objcurrent = oEvent.getSource().getSelectedContexts()[0].getObject();
			var mat = new sap.ui.model.json.JSONModel(objcurrent);
			this._oDialog2.setModel(mat);
		},
		onClose: function() {
			this._getDialog2().close();
		},
		ongoto: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("EHSMDashboard");
		}

	});

});