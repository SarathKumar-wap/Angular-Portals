sap.ui.define([
	"sap/ui/core/mvc/Controller", "sap/m/MessageToast"
], function(Controller,MessageToast) {
	"use strict";

	return Controller.extend("ShopFloorShopFloor.controller.LoginPage", {
		
			onPress: function() {
			var user = this.getView().byId("name").getValue();
			var pass = this.getView().byId("password").getValue();
			window.console.log(user, pass);

			if (user !== "" && pass !== "") {

				var surl = '/sap/opu/odata/sap/ZPP_SHOPFLOOR_SK_SRV/';
				var oModel = new sap.ui.model.odata.ODataModel(surl, true);
				var uri = "UserId='" + user + "',Password='" + pass + "'";
				window.console.log(uri);
				var userdata;
				var status;
				oModel.read("/Z_SF_LOGINSet(" + uri + ")", {
					context: null,
					urlParameters: null,
					async: false,
					success: function(oData, OResponse) {
						window.console.log("Success", oData);
						userdata = oData;
						status = oData["ReturnMsg"];
					}
				});

				var sampleModel = new sap.ui.model.json.JSONModel(userdata);
				sap.ui.getCore().setModel(sampleModel, "baseinfo");

				if (status === "Success") {
					MessageToast.show("Login Successful");
					var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					oRouter.navTo("sfdashboard");

				} else if (status === "Password incorrect") {
					MessageToast.show("Incorrect Password!");
					window.console.log("incorrect password");
				} else {
				
					var error2 = 'User not found';
					MessageToast.show(error2);
					window.console.log("User not found");
				}

			} else {
				MessageToast.show("Fill out the Required Fields");

			}
			user.setValue(" ");
			pass.setValue(" ");

		}

	});
});