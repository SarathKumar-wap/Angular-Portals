sap.ui.define([
	"sap/ui/core/mvc/Controller", "sap/ui/model/Filter", "sap/ui/model/FilterOperator"
], function(Controller, Filter, FilterOperator) {
	"use strict";

	return Controller.extend("ShopFloorShopFloor.controller.sfpomon", {
		ongoto: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("sfdashboard");
		},
		onAfterRendering: function() {
			var odata = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPP_SHOPFLOOR_SK_SRV");
			this.getView().setModel(odata);
			var data = {
				plannedorder: [],
				Month: [{
					MonthNo: "",
					MonthName: "Choose a Month"
				}, {
					MonthNo: "01",
					MonthName: "January"
				}, {
					MonthNo: "02",
					MonthName: "February"
				}, {
					MonthNo: "03",
					MonthName: "March"
				}, {
					MonthNo: "04",
					MonthName: "April"
				}, {
					MonthNo: "05",
					MonthName: "May"
				}, {
					MonthNo: "06",
					MonthName: "June"
				}, {
					MonthNo: "07",
					MonthName: "July"
				}, {
					MonthNo: "08",
					MonthName: "August"

				}, {
					MonthNo: "09",
					MonthName: "September"
				}, {
					MonthNo: "10",
					MonthName: "October"
				}, {
					MonthNo: "11",
					MonthName: "November"
				}, {
					MonthNo: "12",
					MonthName: "December"
				}],
			};

			var otable = this.getView().byId("plannedordertable");
			var monthlist = this.getView().byId("MonthDropdown");
			var omodel = new sap.ui.model.json.JSONModel();
			omodel.setData(data);

			var uri = "?$filter=Plant eq '0001'";

			odata.read("Z_SF_POLISTSet" + uri + "", {
				success: function(oData, response) {
					window.console.log(oData);
					window.console.log(response);
					for (var i = 0; i <= oData.results.length; i++) {
						data.plannedorder.push(oData.results[i]);
					}
					otable.setModel(omodel);
					monthlist.setModel(omodel);
				}

			});

		},
		onsearch: function(oEvt) {
			var aFilters = [];
			var sQuery = oEvt.getSource().getValue();
			window.console.log(sQuery);
			if (sQuery && sQuery.length > 0) {
				var filter = new Filter("PlannedorderNum", FilterOperator.Contains, sQuery);
				aFilters.push(filter);
			}
			// update list binding
			var list = this.getView().byId("plannedordertable");
			var binding = list.getBinding("items");
			binding.filter(aFilters, "Application");
		},
		onChange: function(oEvent) {
			var sValue = oEvent.getParameters().selectedItem.mProperties.key;
			window.console.log(sValue);
			// window.console.log(oEvent.getParameters("Key"));

			var oList = this.getView().byId("plannedordertable");
			window.console.log("oList");
			window.console.log(oList);
			var oItemBinding = oList.getBinding("items");
			window.console.log("oItemBinding");
			window.console.log(oItemBinding);
			if (sValue === "" || sValue === null || sValue === undefined) {
				oItemBinding.filter([]);
				return;
			}
			window.console.log(sValue);
			var oMonthFilter = new sap.ui.model.Filter("PlanOpenDate", sap.ui.model.FilterOperator.Contains, "-" + sValue + "-");
			oItemBinding.filter(oMonthFilter);
		},

		_getDialog2: function() {

			this._oDialog2 = sap.ui.xmlfragment("ShopFloorShopFloor.view.Fragments.PlanorderMonth", this);
			this.getView().addDependent(this._oDialog2);

			return this._oDialog2;
		},
		displayPlanOrder_Month: function(oEvent) {
			this._getDialog2().open();
			var objcurrent2 = oEvent.getSource().getSelectedContexts()[0].getObject();

			var mat = new sap.ui.model.json.JSONModel(objcurrent2);
			this._oDialog2.setModel(mat);
		},
		onClose2: function() {
			this._oDialog2.close();
			this._oDialog2.destroy(true);
		}

	});

});