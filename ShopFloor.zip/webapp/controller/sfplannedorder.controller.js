sap.ui.define([
	"sap/ui/core/mvc/Controller", "sap/ui/model/Filter", "sap/ui/model/FilterOperator"
], function(Controller, Filter, FilterOperator) {
	"use strict";
	return Controller.extend("ShopFloorShopFloor.controller.sfplannedorder", {

		ongoto: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("sfdashboard");
		},
		onAfterRendering: function() {
			var odata = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPP_SHOPFLOOR_SK_SRV");
			this.getView().setModel(odata);
			var data = {
				plannedorder: [],

				Year: [{
					yearkey: "",
					year: "Choose a Year"
				}, {
					yearkey: "2015",
					year: "2015"
				}, {
					yearkey: "2016",
					year: "2016"
				}, {
					yearkey: "2017",
					year: "2017"
				}, {
					yearkey: "2018",
					year: "2018"
				}, {
					yearkey: "2019",
					year: "2019"
				}, {
					yearkey: "2020",
					year: "2020"
				}, {
					yearkey: "2021",
					year: "2021"
				}, {
					yearkey: "2022",
					year: "2022"
				}, {
					yearkey: "2023",
					year: "2023"
				}, {
					yearkey: "2024",
					year: "2024"
				}]
			};

			var otable = this.getView().byId("plannedordertable");

			var yearlist = this.getView().byId("yearDropdown");
			var omodel = new sap.ui.model.json.JSONModel();
			omodel.setData(data);

			var uri = "?$filter=Plant eq '0001'";

			odata.read("Z_SF_POLISTSet" + uri + "", {
				success: function(oData, response) {
					window.console.log(oData);
					window.console.log(response);
					for (var i = 0; i <= oData.results.length; i++) {
						data.plannedorder.push(oData.results[i]);
					}
					otable.setModel(omodel);

					yearlist.setModel(omodel);
				}

			});

		},
		onsearch: function(oEvt) {
			var aFilters = [];
			var sQuery = oEvt.getSource().getValue();
			window.console.log(sQuery);
			if (sQuery && sQuery.length > 0) {
				var filter = new Filter("PlannedorderNum", FilterOperator.Contains, sQuery);
				aFilters.push(filter);
			}
			// update list binding
			var list = this.getView().byId("plannedordertable");
			var binding = list.getBinding("items");
			binding.filter(aFilters, "Application");
		},

		onChange2: function(oEvent) {
			var sValue = oEvent.getParameters().selectedItem.mProperties.key;
			window.console.log(sValue);
			// window.console.log(oEvent.getParameters("Key"));

			var oList = this.getView().byId("plannedordertable");
			window.console.log("oList");
			window.console.log(oList);
			var oItemBinding = oList.getBinding("items");
			window.console.log("oItemBinding");
			window.console.log(oItemBinding);
			if (sValue === "" || sValue === null || sValue === undefined) {
				oItemBinding.filter([]);
				return;
			}
			window.console.log(sValue);
			var oyearFilter = new sap.ui.model.Filter("PlanOpenDate", sap.ui.model.FilterOperator.Contains, +sValue + "-");
			oItemBinding.filter(oyearFilter);
		},

		_getDialog1: function() {

			this._oDialog1 = sap.ui.xmlfragment("ShopFloorShopFloor.view.Fragments.PlanorderYear", this);
			this.getView().addDependent(this._oDialog1);

			return this._oDialog1;
		},
		displayPlanOrderYear: function(oEvent) {
			this._getDialog1().open();
			var objcurrent1 = oEvent.getSource().getSelectedContexts()[0].getObject();

			var mat = new sap.ui.model.json.JSONModel(objcurrent1);
			this._oDialog1.setModel(mat);
		},
		onClose: function() {
			this._oDialog1.close();
			this._oDialog1.destroy(true);
		}

	});

});